﻿namespace frisc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ColumnMemorija = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnAdresa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnLabel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSadrzaj = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxR1 = new System.Windows.Forms.TextBox();
            this.textBoxR2 = new System.Windows.Forms.TextBox();
            this.textBoxR3 = new System.Windows.Forms.TextBox();
            this.textBoxR4 = new System.Windows.Forms.TextBox();
            this.textBoxR5 = new System.Windows.Forms.TextBox();
            this.textBoxR6 = new System.Windows.Forms.TextBox();
            this.textBoxR7 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxPC = new System.Windows.Forms.TextBox();
            this.textBoxR7Prikaz = new System.Windows.Forms.TextBox();
            this.textBoxR6Prikaz = new System.Windows.Forms.TextBox();
            this.textBoxR5Prikaz = new System.Windows.Forms.TextBox();
            this.textBoxR4Prikaz = new System.Windows.Forms.TextBox();
            this.textBoxR3Prikaz = new System.Windows.Forms.TextBox();
            this.textBoxR2Prikaz = new System.Windows.Forms.TextBox();
            this.textBoxR1Prikaz = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxSR = new System.Windows.Forms.TextBox();
            this.textBoxPCPrikaz = new System.Windows.Forms.TextBox();
            this.textBoxSRPrikaz = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnMemorija,
            this.ColumnAdresa,
            this.ColumnLabel,
            this.ColumnSadrzaj});
            this.dataGridView1.Location = new System.Drawing.Point(315, 63);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 30, 3, 40);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.RowTemplate.ReadOnly = true;
            this.dataGridView1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(490, 362);
            this.dataGridView1.TabIndex = 0;
            // 
            // ColumnMemorija
            // 
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Aquamarine;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            this.ColumnMemorija.DefaultCellStyle = dataGridViewCellStyle2;
            this.ColumnMemorija.FillWeight = 200F;
            this.ColumnMemorija.Frozen = true;
            this.ColumnMemorija.HeaderText = "Memorija";
            this.ColumnMemorija.Name = "ColumnMemorija";
            this.ColumnMemorija.ReadOnly = true;
            this.ColumnMemorija.Width = 220;
            // 
            // ColumnAdresa
            // 
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Aquamarine;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            this.ColumnAdresa.DefaultCellStyle = dataGridViewCellStyle3;
            this.ColumnAdresa.FillWeight = 80F;
            this.ColumnAdresa.Frozen = true;
            this.ColumnAdresa.HeaderText = "Adresa";
            this.ColumnAdresa.Name = "ColumnAdresa";
            this.ColumnAdresa.ReadOnly = true;
            this.ColumnAdresa.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnAdresa.Width = 80;
            // 
            // ColumnLabel
            // 
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Aquamarine;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            this.ColumnLabel.DefaultCellStyle = dataGridViewCellStyle4;
            this.ColumnLabel.FillWeight = 70F;
            this.ColumnLabel.Frozen = true;
            this.ColumnLabel.HeaderText = "Label";
            this.ColumnLabel.Name = "ColumnLabel";
            this.ColumnLabel.ReadOnly = true;
            this.ColumnLabel.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnLabel.Width = 70;
            // 
            // ColumnSadrzaj
            // 
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Aquamarine;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            this.ColumnSadrzaj.DefaultCellStyle = dataGridViewCellStyle5;
            this.ColumnSadrzaj.FillWeight = 90F;
            this.ColumnSadrzaj.HeaderText = "Sadržaj";
            this.ColumnSadrzaj.Name = "ColumnSadrzaj";
            this.ColumnSadrzaj.ReadOnly = true;
            this.ColumnSadrzaj.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 157);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "R1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 183);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "R2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 209);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(21, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "R3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 235);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(21, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "R4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 261);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(21, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "R5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(23, 287);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(21, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "R6";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(23, 313);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(21, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "R7";
            // 
            // textBoxR1
            // 
            this.textBoxR1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBoxR1.Location = new System.Drawing.Point(50, 154);
            this.textBoxR1.Name = "textBoxR1";
            this.textBoxR1.ReadOnly = true;
            this.textBoxR1.Size = new System.Drawing.Size(200, 20);
            this.textBoxR1.TabIndex = 8;
            this.textBoxR1.MouseLeave += new System.EventHandler(this.textBoxR1_MouseLeave);
            this.textBoxR1.MouseEnter += new System.EventHandler(this.textBoxR1_MouseEnter);
            // 
            // textBoxR2
            // 
            this.textBoxR2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBoxR2.Location = new System.Drawing.Point(50, 180);
            this.textBoxR2.Name = "textBoxR2";
            this.textBoxR2.ReadOnly = true;
            this.textBoxR2.Size = new System.Drawing.Size(200, 20);
            this.textBoxR2.TabIndex = 9;
            this.textBoxR2.MouseLeave += new System.EventHandler(this.textBoxR2_MouseLeave);
            this.textBoxR2.MouseEnter += new System.EventHandler(this.textBoxR2_MouseEnter);
            // 
            // textBoxR3
            // 
            this.textBoxR3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBoxR3.Location = new System.Drawing.Point(50, 206);
            this.textBoxR3.Name = "textBoxR3";
            this.textBoxR3.ReadOnly = true;
            this.textBoxR3.Size = new System.Drawing.Size(200, 20);
            this.textBoxR3.TabIndex = 10;
            this.textBoxR3.MouseLeave += new System.EventHandler(this.textBoxR3_MouseLeave);
            this.textBoxR3.MouseEnter += new System.EventHandler(this.textBoxR3_MouseEnter);
            // 
            // textBoxR4
            // 
            this.textBoxR4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBoxR4.Location = new System.Drawing.Point(50, 232);
            this.textBoxR4.Name = "textBoxR4";
            this.textBoxR4.ReadOnly = true;
            this.textBoxR4.Size = new System.Drawing.Size(200, 20);
            this.textBoxR4.TabIndex = 11;
            this.textBoxR4.MouseLeave += new System.EventHandler(this.textBoxR4_MouseLeave);
            this.textBoxR4.MouseEnter += new System.EventHandler(this.textBoxR4_MouseEnter);
            // 
            // textBoxR5
            // 
            this.textBoxR5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBoxR5.Location = new System.Drawing.Point(50, 258);
            this.textBoxR5.Name = "textBoxR5";
            this.textBoxR5.ReadOnly = true;
            this.textBoxR5.Size = new System.Drawing.Size(200, 20);
            this.textBoxR5.TabIndex = 12;
            this.textBoxR5.MouseLeave += new System.EventHandler(this.textBoxR5_MouseLeave);
            this.textBoxR5.MouseEnter += new System.EventHandler(this.textBoxR5_MouseEnter);
            // 
            // textBoxR6
            // 
            this.textBoxR6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBoxR6.Location = new System.Drawing.Point(50, 284);
            this.textBoxR6.Name = "textBoxR6";
            this.textBoxR6.ReadOnly = true;
            this.textBoxR6.Size = new System.Drawing.Size(200, 20);
            this.textBoxR6.TabIndex = 13;
            this.textBoxR6.MouseLeave += new System.EventHandler(this.textBoxR6_MouseLeave);
            this.textBoxR6.MouseEnter += new System.EventHandler(this.textBoxR6_MouseEnter);
            // 
            // textBoxR7
            // 
            this.textBoxR7.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBoxR7.Location = new System.Drawing.Point(50, 310);
            this.textBoxR7.Name = "textBoxR7";
            this.textBoxR7.ReadOnly = true;
            this.textBoxR7.Size = new System.Drawing.Size(200, 20);
            this.textBoxR7.TabIndex = 14;
            this.textBoxR7.MouseLeave += new System.EventHandler(this.textBoxR7_MouseLeave);
            this.textBoxR7.MouseEnter += new System.EventHandler(this.textBoxR7_MouseEnter);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(23, 88);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(21, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "PC";
            // 
            // textBoxPC
            // 
            this.textBoxPC.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBoxPC.Location = new System.Drawing.Point(50, 85);
            this.textBoxPC.Name = "textBoxPC";
            this.textBoxPC.ReadOnly = true;
            this.textBoxPC.Size = new System.Drawing.Size(200, 20);
            this.textBoxPC.TabIndex = 16;
            this.textBoxPC.MouseLeave += new System.EventHandler(this.textBoxPC_MouseLeave);
            this.textBoxPC.MouseEnter += new System.EventHandler(this.textBoxPC_MouseEnter);
            // 
            // textBoxR7Prikaz
            // 
            this.textBoxR7Prikaz.Location = new System.Drawing.Point(50, 330);
            this.textBoxR7Prikaz.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxR7Prikaz.Multiline = true;
            this.textBoxR7Prikaz.Name = "textBoxR7Prikaz";
            this.textBoxR7Prikaz.Size = new System.Drawing.Size(200, 45);
            this.textBoxR7Prikaz.TabIndex = 19;
            this.textBoxR7Prikaz.Visible = false;
            // 
            // textBoxR6Prikaz
            // 
            this.textBoxR6Prikaz.Location = new System.Drawing.Point(50, 304);
            this.textBoxR6Prikaz.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxR6Prikaz.Multiline = true;
            this.textBoxR6Prikaz.Name = "textBoxR6Prikaz";
            this.textBoxR6Prikaz.Size = new System.Drawing.Size(200, 45);
            this.textBoxR6Prikaz.TabIndex = 20;
            this.textBoxR6Prikaz.Visible = false;
            // 
            // textBoxR5Prikaz
            // 
            this.textBoxR5Prikaz.Location = new System.Drawing.Point(50, 278);
            this.textBoxR5Prikaz.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxR5Prikaz.Multiline = true;
            this.textBoxR5Prikaz.Name = "textBoxR5Prikaz";
            this.textBoxR5Prikaz.Size = new System.Drawing.Size(200, 45);
            this.textBoxR5Prikaz.TabIndex = 21;
            this.textBoxR5Prikaz.Visible = false;
            // 
            // textBoxR4Prikaz
            // 
            this.textBoxR4Prikaz.Location = new System.Drawing.Point(50, 252);
            this.textBoxR4Prikaz.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxR4Prikaz.Multiline = true;
            this.textBoxR4Prikaz.Name = "textBoxR4Prikaz";
            this.textBoxR4Prikaz.Size = new System.Drawing.Size(200, 45);
            this.textBoxR4Prikaz.TabIndex = 22;
            this.textBoxR4Prikaz.Visible = false;
            // 
            // textBoxR3Prikaz
            // 
            this.textBoxR3Prikaz.Location = new System.Drawing.Point(50, 225);
            this.textBoxR3Prikaz.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxR3Prikaz.Multiline = true;
            this.textBoxR3Prikaz.Name = "textBoxR3Prikaz";
            this.textBoxR3Prikaz.Size = new System.Drawing.Size(200, 45);
            this.textBoxR3Prikaz.TabIndex = 23;
            this.textBoxR3Prikaz.Visible = false;
            // 
            // textBoxR2Prikaz
            // 
            this.textBoxR2Prikaz.Location = new System.Drawing.Point(50, 198);
            this.textBoxR2Prikaz.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxR2Prikaz.Multiline = true;
            this.textBoxR2Prikaz.Name = "textBoxR2Prikaz";
            this.textBoxR2Prikaz.Size = new System.Drawing.Size(200, 45);
            this.textBoxR2Prikaz.TabIndex = 24;
            this.textBoxR2Prikaz.Visible = false;
            // 
            // textBoxR1Prikaz
            // 
            this.textBoxR1Prikaz.Location = new System.Drawing.Point(50, 173);
            this.textBoxR1Prikaz.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxR1Prikaz.Multiline = true;
            this.textBoxR1Prikaz.Name = "textBoxR1Prikaz";
            this.textBoxR1Prikaz.Size = new System.Drawing.Size(200, 45);
            this.textBoxR1Prikaz.TabIndex = 25;
            this.textBoxR1Prikaz.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(22, 114);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(22, 13);
            this.label9.TabIndex = 26;
            this.label9.Text = "SR";
            // 
            // textBoxSR
            // 
            this.textBoxSR.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBoxSR.Location = new System.Drawing.Point(50, 111);
            this.textBoxSR.Name = "textBoxSR";
            this.textBoxSR.ReadOnly = true;
            this.textBoxSR.Size = new System.Drawing.Size(200, 20);
            this.textBoxSR.TabIndex = 27;
            this.textBoxSR.MouseLeave += new System.EventHandler(this.textBoxSR_MouseLeave);
            this.textBoxSR.MouseEnter += new System.EventHandler(this.textBoxSR_MouseEnter);
            // 
            // textBoxPCPrikaz
            // 
            this.textBoxPCPrikaz.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBoxPCPrikaz.Location = new System.Drawing.Point(50, 104);
            this.textBoxPCPrikaz.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxPCPrikaz.Multiline = true;
            this.textBoxPCPrikaz.Name = "textBoxPCPrikaz";
            this.textBoxPCPrikaz.Size = new System.Drawing.Size(200, 35);
            this.textBoxPCPrikaz.TabIndex = 28;
            this.textBoxPCPrikaz.Visible = false;
            // 
            // textBoxSRPrikaz
            // 
            this.textBoxSRPrikaz.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBoxSRPrikaz.Location = new System.Drawing.Point(50, 131);
            this.textBoxSRPrikaz.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxSRPrikaz.Multiline = true;
            this.textBoxSRPrikaz.Name = "textBoxSRPrikaz";
            this.textBoxSRPrikaz.Size = new System.Drawing.Size(200, 35);
            this.textBoxSRPrikaz.TabIndex = 29;
            this.textBoxSRPrikaz.Visible = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(805, 24);
            this.menuStrip1.TabIndex = 30;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.restartToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.menuToolStripMenuItem.Text = "Meni";
            // 
            // restartToolStripMenuItem
            // 
            this.restartToolStripMenuItem.Name = "restartToolStripMenuItem";
            this.restartToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.restartToolStripMenuItem.Text = "Restiraj";
            this.restartToolStripMenuItem.Click += new System.EventHandler(this.restartToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.exitToolStripMenuItem.Text = "Izlaz";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton4,
            this.toolStripButton3,
            this.toolStripSeparator1,
            this.toolStripLabel1,
            this.toolStripButton1,
            this.toolStripButton2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(805, 25);
            this.toolStrip1.TabIndex = 32;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.Image = global::frisc.Properties.Resources.Download_48;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(80, 22);
            this.toolStripButton4.Text = "Učitaj kod";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.Image = global::frisc.Properties.Resources.Restart_48;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(71, 22);
            this.toolStripButton3.Text = "Resetiraj";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Margin = new System.Windows.Forms.Padding(5, 0, 10, 0);
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel1.Text = "Izvedi :";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = global::frisc.Properties.Resources.play_icon;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(104, 22);
            this.toolStripButton1.Text = "jednu naredbu";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = global::frisc.Properties.Resources.forward_icon;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(90, 22);
            this.toolStripButton2.Text = "sve naredbe";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(805, 446);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.textBoxPCPrikaz);
            this.Controls.Add(this.textBoxSRPrikaz);
            this.Controls.Add(this.textBoxSR);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBoxR1Prikaz);
            this.Controls.Add(this.textBoxR2Prikaz);
            this.Controls.Add(this.textBoxR3Prikaz);
            this.Controls.Add(this.textBoxR4Prikaz);
            this.Controls.Add(this.textBoxR5Prikaz);
            this.Controls.Add(this.textBoxR6Prikaz);
            this.Controls.Add(this.textBoxR7Prikaz);
            this.Controls.Add(this.textBoxPC);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBoxR7);
            this.Controls.Add(this.textBoxR6);
            this.Controls.Add(this.textBoxR5);
            this.Controls.Add(this.textBoxR4);
            this.Controls.Add(this.textBoxR3);
            this.Controls.Add(this.textBoxR2);
            this.Controls.Add(this.textBoxR1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Padding = new System.Windows.Forms.Padding(0, 0, 0, 20);
            this.Text = "Frisc";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxR1;
        private System.Windows.Forms.TextBox textBoxR2;
        private System.Windows.Forms.TextBox textBoxR3;
        private System.Windows.Forms.TextBox textBoxR4;
        private System.Windows.Forms.TextBox textBoxR5;
        private System.Windows.Forms.TextBox textBoxR6;
        private System.Windows.Forms.TextBox textBoxR7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxPC;
        private System.Windows.Forms.TextBox textBoxR7Prikaz;
        private System.Windows.Forms.TextBox textBoxR6Prikaz;
        private System.Windows.Forms.TextBox textBoxR5Prikaz;
        private System.Windows.Forms.TextBox textBoxR4Prikaz;
        private System.Windows.Forms.TextBox textBoxR3Prikaz;
        private System.Windows.Forms.TextBox textBoxR2Prikaz;
        private System.Windows.Forms.TextBox textBoxR1Prikaz;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxSR;
        private System.Windows.Forms.TextBox textBoxPCPrikaz;
        private System.Windows.Forms.TextBox textBoxSRPrikaz;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restartToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMemorija;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnAdresa;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnLabel;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSadrzaj;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
    }
}

